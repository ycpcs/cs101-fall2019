// CS101-103: Exam 2 Fall 2019 - Question 10 (15 points)
#include <stdio.h>

double dropLowest(int q1, int q2, int q3);

int main(void) {
	int x1,x2,x3;
	printf("Enter 3 values: ");
	scanf("%i %i %i", &x1,&x2,&x3);

	double avg = 0.0;
	
	// IMPORTANT: don't modify any of the code above this comment
	
	// TODO: Add function call here
	
	// IMPORTANT: don't modify any of the code below this comment
	
	printf("The average is %.1lf.\n", avg);
	return 0;

}

// TODO: add a definition for the dropLowest function
double dropLowest(int q1, int q2, int q3) {


}

