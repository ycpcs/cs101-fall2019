// CS101-102: Exam 1 Fall 2019 - Question 12 (20 points)

#include <stdio.h>
#include <math.h>

int main(void) {

	// TODO: Get initial heights
	
	// TODO: Compute impact velocities
	
	// TODO: Determine larger velocity

	return 0;
}
