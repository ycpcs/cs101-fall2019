// CS101-103: Exam 1 Fall 2019 - Question 13 (15 points)

#include <stdio.h>

int main(void) {

	// Get length of bar from user
	int n;
	printf("Enter the bar length: ");
	scanf("%i", &n);
	
	// TODO: Print bar

	return 0;
}
