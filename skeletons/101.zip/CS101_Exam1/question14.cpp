// CS101-101: Exam 1 Fall 2019 - Question 14 (15 points)

#include <stdio.h>

int main(void) {

	// Get integers from user
	int num1, num2;
	printf("Enter two integers: ");
	scanf("%i %i",&num1, &num2);

	// TODO: Determine larger input
	int larger;

	// TODO: Determine least common multiple


	return 0;
}
