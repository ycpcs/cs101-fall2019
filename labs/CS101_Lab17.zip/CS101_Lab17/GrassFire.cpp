#include <stdio.h>

// TODO: add function prototypes

int main(void) {
	// TODO: add your code here

	return 0;
}

// TODO: add function definitions
