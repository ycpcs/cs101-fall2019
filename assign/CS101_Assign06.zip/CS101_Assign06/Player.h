#ifndef PLAYER_H
#define PLAYER_H

#include <stdlib.h>
#include "Const.h"
#include "Console.h"

// TODO MS1: Add player structure

// TODO MS1: Add player function prototypes

#endif // PLAYER_H
