#ifndef SCENE_H
#define SCENE_H

#include <stdio.h>
#include <stdlib.h>
#include "Console.h"
#include "Const.h"
#include "Player.h"

struct Scene {
	int board[HEIGHT][WIDTH];
	int num_pellets;
	int num_powerups;
	// TODO: add additional fields
};

void initialize_Scene(Scene *s);
void render_Scene(Scene *s);
int update_Scene(Scene *s);
void load_Board(int board[HEIGHT][WIDTH], int *num_pellets, int *num_powerups);
void draw_Board(int board[HEIGHT][WIDTH]);

#endif // SCENE_H
