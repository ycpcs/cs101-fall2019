// CS101 Assignment 3 - Fall 2018
#include <stdio.h>

int main() {
	// TODO: Add code

	return 0;
}