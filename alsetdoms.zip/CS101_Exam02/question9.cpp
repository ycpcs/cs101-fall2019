// CS101-101: Exam 2 Fall 2019 - Question 9 (20 points)
#include <stdio.h>

#define MAX 100

int main(void) {
	int values[MAX];
	int num_values;

	printf("How many values? ");
	scanf("%i", &num_values);

	if (num_values > MAX) {
		printf("Too many values, sorry\n");
		return 1;
	}

	printf("Enter the values: ");
	for (int i = 0; i < num_values; i++) {
		scanf("%i", &values[i]);
	}

	// IMPORTANT: don't modify any of the code above this comment

	// TODO: add your code here

	// IMPORTANT: don't modify any of the code below this comment

	printf("After swapping even pairs:\n");
	for (int i = 0; i < num_values; i++) {
		printf("%i ", values[i]);
	}
	printf("\n");

	return 0;
}
