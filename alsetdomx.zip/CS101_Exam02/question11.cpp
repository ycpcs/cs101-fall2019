// CS101-102: Exam 2 Fall 2019 - Question 11 (25 points)
#include <stdio.h>

// TODO: add a prototype for the arrow_score function

// EXTREMELY IMPORTANT: do not modify the main function in any way
int main(void) {
	double arrow_dist;
	printf("Distance of arrow from target center: ");
	scanf("%lf", &arrow_dist);

	int score;
	score = arrow_score(arrow_dist);

	printf("Score is %i\n", score);

	return 0;
}

// TODO: add a definition for the arrow_score function

